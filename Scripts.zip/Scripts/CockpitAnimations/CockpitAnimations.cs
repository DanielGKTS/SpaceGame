using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CockpitAnimations : MonoBehaviour
{
    [SerializeField] Transform joystick;



    [SerializeField] Vector3 _joystickRange = Vector3.zero;

    [SerializeField]
    List<Transform> _throttles;

    [SerializeField]
    float throttleRange = 35f;

    [SerializeField]
    ShipMovementInput _movementInput;

    IMovementControls ControlInput => _movementInput.MovementControls; 


    // Update is called once per frame
    void Update()
    {
        joystick.localRotation = Quaternion.Euler(

            ControlInput.PitchAmount * _joystickRange.x, 
            ControlInput.YawAmount * _joystickRange.y, 
            ControlInput.RollAmount * _joystickRange.z
           // ControlInput.ThrustAmount * _joystickRange.x


            );

        Vector3 throttleRotation = _throttles[0].localRotation.eulerAngles;
        throttleRotation.x = ControlInput.ThrustAmount * throttleRange;

        foreach (Transform throttle in _throttles)
        {
            throttle.localRotation = Quaternion.Euler(throttleRotation); 
        }



    }
}
