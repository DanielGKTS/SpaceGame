using UnityEngine;

public class ShipControl : MonoBehaviour
{
    [SerializeField] float _yawSpeed = 60f;
    [SerializeField] float _thrustSpeed = 100f;
    [SerializeField] float _pitchSpeed = 60f;
    [SerializeField] float _rollSpeed = 60f;

    Rigidbody _rigidbody;

    float _yawInput;
    float _thrustInput;
    float _pitchInput;
    float _rollInput;

    void Start()
    {
        _rigidbody = GetComponent<Rigidbody>();
    }

    void Update()
    {
        //Axis such as horizontal and vertical have already been created in unity for you 
        //Yoou will need to create the pitch and roll axis so make sure to map them to something that you are comfortable with
        _yawInput = Input.GetAxis("Horizontal");
        _thrustInput = Input.GetAxis("Thrust");
        _pitchInput = Input.GetAxis("Pitch");
        _rollInput = Input.GetAxis("Roll");
    }

    void FixedUpdate()
    {
        ApplyYaw();
        ApplyThrust();
        ApplyPitch();
        ApplyRoll();
    }

    void ApplyYaw()
    {
        float yaw = _yawInput * _yawSpeed * Time.fixedDeltaTime;
        _rigidbody.rotation *= Quaternion.Euler(0f, yaw, 0f);
    }

    void ApplyThrust()
    {
        float thrust = _thrustInput * _thrustSpeed * Time.fixedDeltaTime;
        Vector3 force = transform.forward * thrust;
        _rigidbody.AddForce(force, ForceMode.Force);
    }

    void ApplyPitch()
    {
        float pitch = _pitchInput * _pitchSpeed * Time.fixedDeltaTime;
        Vector3 rotation = new Vector3(pitch, 0f, 0f);
        _rigidbody.rotation *= Quaternion.Euler(rotation);
    }

    void ApplyRoll()
    {
        float roll = _rollInput * _rollSpeed * Time.fixedDeltaTime;
        Vector3 rotation = new Vector3(0f, 0f, -roll);
        _rigidbody.rotation *= Quaternion.Euler(rotation);
    }
}


