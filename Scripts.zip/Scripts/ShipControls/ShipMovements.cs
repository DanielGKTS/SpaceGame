using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(Rigidbody))]

public class ShipMovements : MonoBehaviour
{

    [SerializeField] ShipMovementInput _movementInput;


    [SerializeField]
    [Range(1000f, 10000f)]
    float _thrustForce = 7500f,
         _pitchForce = 6000f, _rollForce = 1000f, _yawForce = 2000f;

    Rigidbody _rigidbody;

    [SerializeField][Range(-1f, 1f)] float _thrustAmount, _pitchAmount, _rollAmount, _yawAmount;


    IMovementControls ControlInput => _movementInput.MovementControls;


    

    void Awake()
    {
        _rigidbody = GetComponent<Rigidbody>();
    }

    void update()
    {
        _thrustAmount = ControlInput.ThrustAmount;
        _rollAmount = ControlInput.RollAmount;
        _yawAmount = ControlInput.YawAmount;
        _pitchAmount = ControlInput.PitchAmount;

    }

    void FixedUpdate()
    {
        // Thrust
        if (!Mathf.Approximately(0f, _thrustAmount))
        {
            _rigidbody.AddForce(transform.forward * (_thrustForce * _thrustAmount * Time.fixedDeltaTime));
        }

        // Pitch
        if (!Mathf.Approximately(0f, _pitchAmount))
        {
            _rigidbody.AddTorque(transform.right * (_pitchForce * _pitchAmount * Time.fixedDeltaTime));
        }

        // Roll
        if (!Mathf.Approximately(0f, _rollAmount))
        {
            _rigidbody.AddTorque(transform.forward * (_rollForce * _rollAmount * Time.fixedDeltaTime));
        }

        // Yaw
        if (!Mathf.Approximately(0f, _yawAmount))
        {
            _rigidbody.AddTorque(transform.up * (_yawForce * _yawAmount * Time.fixedDeltaTime));
        }
    }







   

}










