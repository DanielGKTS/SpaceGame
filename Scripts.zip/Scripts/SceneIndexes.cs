using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum SceneIndexes
{
    MANAGER = 0, 
    MENU = 1, 
    SAMPLE_SCENE = 2 
  
}
