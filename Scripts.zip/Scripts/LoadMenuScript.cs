using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadMenu : MonoBehaviour
{
    public string run; 



    
    private IEnumerator change()
    {
        yield return new WaitForSeconds(3.0f);
        SceneManager.LoadScene(run);  

    }
}

/*
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    [SerializeField] GameObject mainPanel;
    [SerializeField] GameObject lorePanel;
    [SerializeField] GameObject loadingPanel;



    public void GotoMain()
    {
        mainPanel.SetActive(true);
        lorePanel.SetActive(false);
    }



    public void GotoLore()
    {
        mainPanel.SetActive(false);
        lorePanel.SetActive(true);
    }

    public void GoBack()
    {
        mainPanel.SetActive(true);
        lorePanel.SetActive(false);
    }




    public void OnClickPLay()
    {
        SceneManager.LoadScene("LoadingScene");
    }
*/


