using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movements : MonoBehaviour
{
    public float moveSpeed = 10f; // Speed of ship movement
    public float turnSpeed = 50f; // Speed of ship turning
    public float rollSpeed = 50f; // Speed of ship rolling
    public float maxRollAngle = 30f; // Maximum angle the ship can roll
    private float currentRollAngle = 0f;



    public Transform cameraTransform;
    public float cameraDistance = 10f;
    public float cameraHeight = 5f;

    private Rigidbody shipRigidbody; // Reference to the ship's rigidbody

    void Start()
    {
        shipRigidbody = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        float horizontalInput = Input.GetAxis("Horizontal"); // Get horizontal input (left/right arrow keys)
        float verticalInput = Input.GetAxis("Vertical"); // Get vertical input (up/down arrow keys)
        float rollInput = Input.GetAxis("Roll"); // Get roll input (Q/E keys)

        // Move the ship forward/backward and left/right
        Vector3 movement = (transform.forward * verticalInput + transform.right * horizontalInput) * moveSpeed * Time.deltaTime;
        shipRigidbody.MovePosition(shipRigidbody.position + movement);

        // Turn the ship left/right and roll left/right
        float turn = horizontalInput * turnSpeed * Time.deltaTime;
        float roll = rollInput * rollSpeed * Time.deltaTime;
        currentRollAngle = Mathf.Clamp(currentRollAngle + roll, -maxRollAngle, maxRollAngle);
        Quaternion turnRotation = Quaternion.Euler(0f, turn, currentRollAngle);
        shipRigidbody.MoveRotation(shipRigidbody.rotation * turnRotation);

        // Position the camera behind and above the ship
        Vector3 cameraPosition = transform.position - transform.forward * cameraDistance + Vector3.up * cameraHeight;
        cameraTransform.position = cameraPosition;
        cameraTransform.LookAt(transform);
    }

}


