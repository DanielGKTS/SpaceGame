using System.Collections;
using System.Collections.Generic;
using UnityEngine.InputSystem;
using UnityEngine;

public class Blaster : MonoBehaviour
{

    public GameObject projectilePrefab;

    public Transform muzzle;
    public Transform blaster_rot;
    public Texture2D guiTexture;

   // [SerializeField][Range(0f, 5f)] float coolDownTime = 0.25f;


    //bool CanFire
  //  {
  //      get
   //     {
   //         coolDown -= Time.deltaTime;
   //         return coolDown <= 0f;
  //      }
  //  }

   // float coolDown; 



    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            FireProjectile();
        }

    }


    void FireProjectile()
    {
        //coolDown = coolDownTime;
        //Instantiate(projectilePrefab, muzzle.position, transform.rotation);

        GameObject go = GameObject.Instantiate(projectilePrefab, muzzle.position, muzzle.rotation) as GameObject;
        GameObject.Destroy(go, 3f);

    }
}
